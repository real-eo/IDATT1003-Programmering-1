package no.gloppen.eiendom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Register for eiendommer. Håndterer lagring og enkle søk/analyser.
 */
public class PropertyRegister {
    private final List<Property> properties = new ArrayList<>();

    /**
     * Legger til en eiendom hvis den ikke finnes fra før.
     * @param property eiendommen
     * @return true hvis lagt til, false hvis duplikat
     */
    public boolean addProperty(Property property) {
        if (property == null) return false;
        if (properties.contains(property)) return false; // uniqueness by equals()
        properties.add(property);
        return true;
    }

    /**
     * @return en umodifiserbar liste over alle eiendommer
     */
    public List<Property> getAll() {
        return Collections.unmodifiableList(properties);
    }

    /**
     * Finner en eiendom basert på kommunenr, gnr og bnr.
     * @param municipalityNumber kommunenummer
     * @param lotNumber gnr
     * @param sectionNumber bnr
     * @return Optional med eiendom hvis funnet
     */
    public Optional<Property> find(int municipalityNumber, int lotNumber, int sectionNumber) {
        for (Property p : properties) {
            if (p.getMunicipalityNumber() == municipalityNumber &&
                p.getLotNumber() == lotNumber &&
                p.getSectionNumber() == sectionNumber) {
                return Optional.of(p);
            }
        }
        return Optional.empty();
    }

    /**
     * Beregner gjennomsnittlig areal.
     * @return gjennomsnitt eller 0.0 hvis tomt
     */
    public double averageArea() {
        if (properties.isEmpty()) return 0.0;
        double sum = 0.0;
        for (Property p : properties) {
            sum += p.getAreaSqm();
        }
        return sum / properties.size();
    }

    /**
     * Antall registrerte eiendommer.
     */
    public int size() { return properties.size(); }
}
