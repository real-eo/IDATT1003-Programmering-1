package no.gloppen.eiendom;

import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Optional;
import java.util.Scanner;

/**
 * Tekstbasert applikasjon for Gloppen kommune sitt eiendomsregister.
 */
public class RealEstateApp {

    private final PropertyRegister register = new PropertyRegister();
    private final Scanner scanner = new Scanner(System.in).useLocale(Locale.US);

    public static void main(String[] args) {
        RealEstateApp app = new RealEstateApp();
        app.seedTestData();
        app.run();
    }

    /**
     * Legger inn testdata gitt i oppgaveteksten.
     */
    private void seedTestData() {
        register.addProperty(new Property(1445, "Gloppen", 77, 631, "", 1017.6, "Jens Olsen"));
        register.addProperty(new Property(1445, "Gloppen", 77, 131, "Syningom", 661.3, "Nicolay Madsen"));
        register.addProperty(new Property(1445, "Gloppen", 75, 19, "Fugletun", 650.6, "Evilyn Jensen"));
        register.addProperty(new Property(1445, "Gloppen", 74, 188, "", 1457.2, "Karl Ove Bråten"));
        register.addProperty(new Property(1445, "Gloppen", 69, 47, "Høiberg", 1339.4, "Elsa Indregård"));
    }

    private void run() {
        System.out.println("Velkommen til Gloppen eiendomsregister!\n");
        boolean done = false;
        while (!done) {
            printMenu();
            int choice = readInt("Velg menyvalg: ");
            switch (choice) {
                case 1 -> menuAddProperty();
                case 2 -> menuListAll();
                case 3 -> menuSearch();
                case 4 -> menuAverageArea();
                case 5 -> {
                    System.out.println("Avslutter. Ha en fin dag!");
                    done = true;
                }
                default -> System.out.println("Ugyldig valg, prøv igjen.\n");
            }
        }
    }

    private void printMenu() {
        System.out.println("----- MENY -----");
        System.out.println("1. Registrer ny eiendom");
        System.out.println("2. Skriv ut alle eiendommer");
        System.out.println("3. Søk etter eiendom (kommunenr, gnr, bnr)");
        System.out.println("4. Vis gjennomsnittsareal");
        System.out.println("5. Avslutt");
    }

    private void menuAddProperty() {
        System.out.println("\nRegistrer ny eiendom:");
        int knr = readIntWithinRange("Kommunenummer (101-5054): ", 101, 5054);
        String kNavn = readNonEmptyString("Kommunenavn: ");
        int gnr = readPositiveInt("Gårdsnummer (gnr >0): ");
        int bnr = readPositiveInt("Bruksnummer (bnr >0): ");
        String bNavn = readOptionalString("Bruksnavn (blank hvis ingen): ");
        double areal = readPositiveDouble("Areal i m2 (>0, bruk punktum som desimal): ");
        String eier = readNonEmptyString("Navn på eier: ");

        try {
            Property p = new Property(knr, kNavn, gnr, bnr, bNavn, areal, eier);
            if (register.addProperty(p)) {
                System.out.println("Eiendom lagt til: " + p.idString());
            } else {
                System.out.println("Eiendommen finnes allerede (duplikat)." );
            }
        } catch (IllegalArgumentException ex) {
            System.out.println("Feil: " + ex.getMessage());
        }
        System.out.println();
    }

    private void menuListAll() {
        System.out.println("\nAlle eiendommer (" + register.size() + "):");
        if (register.size() == 0) {
            System.out.println("(Ingen registrert)");
        } else {
            for (Property p : register.getAll()) {
                System.out.println(p);
            }
        }
        System.out.println();
    }

    private void menuSearch() {
        System.out.println("\nSøk etter eiendom:");
        int knr = readInt("Kommunenummer: ");
        int gnr = readInt("Gårdsnummer (gnr): ");
        int bnr = readInt("Bruksnummer (bnr): ");
        Optional<Property> opt = register.find(knr, gnr, bnr);
        if (opt.isPresent()) {
            System.out.println("Funnet: " + opt.get());
        } else {
            System.out.println("Ingen eiendom med nøkkel " + knr + "-" + gnr + "/" + bnr);
        }
        System.out.println();
    }

    private void menuAverageArea() {
        double avg = register.averageArea();
        if (register.size() == 0) {
            System.out.println("Ingen eiendommer registrert, gjennomsnitt = 0.0");
        } else {
            System.out.printf(Locale.US, "Gjennomsnittlig areal: %.2f m² (%d eiendommer)%n", avg, register.size());
        }
        System.out.println();
    }

    // --- Input hjelpemetoder ---

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int val = Integer.parseInt(scanner.nextLine().trim());
                return val;
            } catch (NumberFormatException ex) {
                System.out.println("Ugyldig heltall, prøv igjen.");
            }
        }
    }

    private int readIntWithinRange(String prompt, int min, int max) {
        while (true) {
            int val = readInt(prompt);
            if (val < min || val > max) {
                System.out.println("Tall må være mellom " + min + " og " + max + ".");
            } else return val;
        }
    }

    private int readPositiveInt(String prompt) {
        while (true) {
            int val = readInt(prompt);
            if (val <= 0) {
                System.out.println("Må være > 0.");
            } else return val;
        }
    }

    private double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                double d = Double.parseDouble(line);
                if (d <= 0) {
                    System.out.println("Må være > 0.");
                } else return d;
            } catch (NumberFormatException ex) {
                System.out.println("Ugyldig desimaltall, bruk punktum (f.eks. 1234.5). ");
            }
        }
    }

    private String readNonEmptyString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = scanner.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Kan ikke være tomt.");
        }
    }

    private String readOptionalString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
}
